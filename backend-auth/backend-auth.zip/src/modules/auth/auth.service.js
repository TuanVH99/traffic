const User = require("../users/user.model");
const RefreshToken = require("./refreshToken.model");
const { hashPassword, verifyPassword, sha256 } = require("../../utils/hash");
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require("../../utils/jwt");
const { env } = require("../../config/env");
const { parseDurationToMs } = require("../../utils/time");

function normalizeEmail(email) {
  return String(email).trim().toLowerCase();
}

function sanitizeUser(userDoc) {
  const u = userDoc.toObject ? userDoc.toObject() : userDoc;
  return {
    id: String(u._id),
    email: u.email,
    name: u.name,
    roles: u.roles,
    status: u.status,
    createdAt: u.createdAt,
    updatedAt: u.updatedAt,
  };
}

async function register({ email, password, name }) {
  const normalized = normalizeEmail(email);

  const existing = await User.findOne({ email: normalized }).lean();
  if (existing) {
    const err = new Error("Email already in use");
    err.statusCode = 409;
    err.code = "EMAIL_IN_USE";
    throw err;
  }

  const passwordHash = await hashPassword(password);

  const user = await User.create({
    email: normalized,
    passwordHash,
    name: name || "",
    roles: ["user"],
    status: "active",
  });

  return sanitizeUser(user);
}

async function login({ email, password }, meta = {}) {
  const normalized = normalizeEmail(email);

  const user = await User.findOne({ email: normalized });
  if (!user) {
    const err = new Error("Invalid credentials");
    err.statusCode = 401;
    err.code = "INVALID_CREDENTIALS";
    throw err;
  }
  if (user.status !== "active") {
    const err = new Error("Account is disabled");
    err.statusCode = 403;
    err.code = "ACCOUNT_DISABLED";
    throw err;
  }

  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) {
    const err = new Error("Invalid credentials");
    err.statusCode = 401;
    err.code = "INVALID_CREDENTIALS";
    throw err;
  }

  const payload = { sub: String(user._id), roles: user.roles };
  const accessToken = signAccessToken(payload);

  // refresh token chỉ cần sub
  const refreshToken = signRefreshToken({ sub: payload.sub });

  // lưu refresh token hash vào DB
  const ttlMs = parseDurationToMs(env.refreshTokenTtl);
  const expiresAt = new Date(Date.now() + ttlMs);

  await RefreshToken.create({
    userId: user._id,
    tokenHash: sha256(refreshToken),
    expiresAt,
    revokedAt: null,
    userAgent: meta.userAgent || "",
    ip: meta.ip || "",
  });

  return { user: sanitizeUser(user), accessToken, refreshToken };
}

async function refresh(refreshToken) {
  if (!refreshToken) {
    const err = new Error("Missing refresh token");
    err.statusCode = 401;
    err.code = "NO_REFRESH_TOKEN";
    throw err;
  }

  let decoded;
  try {
    decoded = verifyRefreshToken(refreshToken);
  } catch {
    const err = new Error("Invalid/expired refresh token");
    err.statusCode = 401;
    err.code = "INVALID_REFRESH_TOKEN";
    throw err;
  }

  const tokenHash = sha256(refreshToken);

  const record = await RefreshToken.findOne({ tokenHash }).lean();
  if (!record || record.revokedAt) {
    const err = new Error("Refresh token revoked");
    err.statusCode = 401;
    err.code = "REFRESH_REVOKED";
    throw err;
  }

  const user = await User.findById(decoded.sub).lean();
  if (!user || user.status !== "active") {
    const err = new Error("Unauthorized");
    err.statusCode = 401;
    err.code = "UNAUTHORIZED";
    throw err;
  }

  const accessToken = signAccessToken({ sub: String(user._id), roles: user.roles });
  return { accessToken };
}

async function logout(refreshToken) {
  if (!refreshToken) return;

  const tokenHash = sha256(refreshToken);
  await RefreshToken.updateOne(
    { tokenHash, revokedAt: null },
    { $set: { revokedAt: new Date() } }
  );
}

module.exports = { register, login, refresh, logout };
